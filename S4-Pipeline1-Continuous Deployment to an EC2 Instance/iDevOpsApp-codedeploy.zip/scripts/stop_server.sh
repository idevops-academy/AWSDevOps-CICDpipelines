#!/bin/bash

#stop the app
pm2 stop idevopsapp